defmodule PythonLexer do
  # This module provides functions for highlighting Python syntax in a file

  def highlight_syntax(file_path) do
    # Reads the file contents
    file = File.read!(file_path)

    # Tokenizes the file contents
    tokens = tokenize(file)

    # Generates HTML representation of the tokens
    html = generate_html(tokens)

    # Writes the HTML output to a file
    File.write("output.html", html)
  end

  def tokenize(file) do
    # Regular expressions for different types of tokens
    regex_comments = ~r/^#.*/  # Matches single line comments starting with '#' and the text with it
    regex_string_literals = ~r/^("([^"\\]|\\.)*"|'([^'\\]|\\.)*')/  # Matches string literals
    regex_boolean_literals = ~r/^(True|False)/  # Matches boolean literals (True, False)
    regex_operators = ~r/^(\+|\-|\*|\/|%|=|==|!=|>|<|>=|<=|and|or|not)/  # Matches operators
    regex_none_literal = ~r/^(None)/  # Matches the 'None' literal
    regex_delimiters = ~r/^(\(|\)|\[|\]|\{|\}|,|:|\.)/  # Matches delimiters
    regex_keywords = ~r/^(input|int|float|if|else|range|elif|while|for|in|def|class|try|except|finally|raise|import|from|as|return|break|continue|pass|global|nonlocal|lambda|with|assert|yield|print)/  # Matches keywords
    regex_identifiers = ~r/^(?:'[^']*'|"[^"]*"|[a-zA-Z_][a-zA-Z0-9_]*)\b/  # Matches identifiers (variables)
    regex_numerical_literals = ~r/^(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?/  # Matches numerical literals
    regex_whitespace = ~r/^\s/# Matches whitespace

    token_list = [
      {regex_comments, :comment},
      {regex_string_literals, :string_literal},
      {regex_boolean_literals, :boolean_literal},
      {regex_operators, :operator},
      {regex_none_literal, :none_literal},
      {regex_delimiters, :delimiter},
      {regex_keywords, :keyword},
      {regex_identifiers, :identifier},
      {regex_numerical_literals, :numeric_literal},
      {regex_whitespace, :whitespace}
    ]

    tokenize_tokens(file, [], token_list, token_list)
  end

  defp tokenize_tokens("", acc, _, _), do: acc
  defp tokenize_tokens(file, acc, [{regex, category} | rest], token_list) do
    case Regex.run(regex, file) do
      [token | _] ->
        token_end_pos = String.length(token) - 1
        categorized_token = {category, token}
        remaining_file = String.slice(file, token_end_pos + 1..-1)
        tokenize_tokens(remaining_file, acc ++ [categorized_token], token_list, token_list)
      _ ->
        tokenize_tokens(file, acc, rest, token_list)
    end
  end

  def generate_html(tokens) do
    # HTML header for the output file
    html_header = """
      <!DOCTYPE html>
      <html>
      <head>
      <link href="Final/syntax_highlighter.css" type="text/css" rel="stylesheet">
      </head>
      <body>
      <pre>
    """

    # Converts each token to an HTML-safe representation
    html_tokens = Enum.map(tokens, fn {category, value} ->
      html_value = String.replace(value, "&", "&amp;")
      html_value = String.replace(html_value, "<", "&lt;")
      html_value = String.replace(html_value, ">", "&gt;")
      html_value = String.replace(html_value, "\n", "<br>")
      "<span class=\"#{category}\">#{html_value}</span>"
    end)

    # Concatenates the HTML header, token elements, and footer
    html = html_header <> Enum.join(html_tokens) <> "</pre></body></html>"

    html  # Returns the generated HTML
  end


end

# Calls the highlight_syntax function with the path to the python test files
#PythonLexer.highlight_syntax("test_one.py")
#PythonLexer.highlight_syntax("test_two.py")
PythonLexer.highlight_syntax("test_three.py")
