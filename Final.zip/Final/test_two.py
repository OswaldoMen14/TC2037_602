def welcome_student(name):
    print(f"Hi, {name}! Welcome to class.")

def imprimirpatron():
    size = 4
    for i in range(size):
        print("*" * size)

def imprimirpatron(num_rows):
    for i in range(num_rows):
        for num_cols in range(num_rows-i):
            print("*", end="")
        print()

def imprimirsuma(a, b):
    print(a + b)

def imprimirpatron(num_rows, char):
	for i in range(num_rows):
		for num_cols in range(num_rows-i):
			print(char, end="")
		print()

