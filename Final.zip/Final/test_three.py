# Define a dictionary
customers = {'06753': 'Mehzabin Afroze', '02457': 'Md. Ali',
             '02834': 'Mosarof Ahmed', '05623': 'Mila Hasan', '07895': 'Yaqub Ali'}

# Append a new data
customers['05634'] = 'Mehboba Ferdous'

print("The customer names are:")
# Print the values of the dictionary
for customer in customers:
    print(customers[customer])

# Take customer ID as input to search
name = input("Enter customer ID:")

# Search the ID in the dictionary
for customer in customers:
    if customer == name:
        print(customers[customer])
        break


# Initialize counter
counter = 1
# Iterate the loop 5 times
while counter < 6:
    # Print the counter value
    print("The current counter value: %d" % counter)
    # Increment the counter
    counter = counter + 1

# Initialize the list
weekdays = ["Sunday", "Monday", "Tuesday",
            "Wednesday", "Thursday", "Friday", "Saturday"]
print("Seven Weekdays are:\n")
# Iterate the list using for loop
for day in range(len(weekdays)):
    print(weekdays[day])

    # Create a list of characters using list comprehension
char_list = [char for char in "linuxhint"]
print(char_list)

# Define a tuple of websites
websites = ("google.com", "yahoo.com", "ask.com", "bing.com")

# Create a list from tuple using list comprehension
site_list = [site for site in websites]
print(site_list)

# Define the string
string = 'Python Bash Java Python PHP PERL'
# Define the search string
search = 'Python'
# Store the count value
count = string.count(search)
# Print the formatted output
print("%s appears %d times" % (search, count))

# Take MCQ marks
mcq_marks = float(input("Enter the MCQ marks: "))
# Take theory marks
theory_marks = float(input("Enter the Theory marks: "))

# Check the passing condition using AND and OR operator
if (mcq_marks >= 40 and theory_marks >= 30) or (mcq_marks + theory_marks) >= 70:
    print("\nYou have passed")
else:
    print("\nYou have failed")

# Switcher for implementing switch case options
def employee_details(ID):
    switcher = {
        "1004": "Employee Name: MD. Mehrab",
        "1009": "Employee Name: Mita Rahman",
        "1010": "Employee Name: Sakib Al Hasan",
    }
    return switcher.get(ID, "nothing")

# Take the employee ID
ID = input("Enter the employee ID: ")
# Print the output
print(employee_details(ID))