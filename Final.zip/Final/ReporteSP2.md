# Análisis de Tiempos de Ejecución y Complejidad del Código del resaltador de sintaxis paralelo de Python
#### Dulce Daniela García Ruíz A01748013
#### Oswaldo Ilhuicatzi Mendizábal A01781988

El código es una versión mejorada de la primer entrega en la cual el código se encuentra dentro del módulo `PythonLexer` que está escrito en el lenguaje funcional Elixir y se utiliza para resaltar la sintaxis de Python en un archivo y generar un archivo HTML de salida. Sin embargo, esta vez se hace de manera paralela para resaltar múltiples archivos dentro de un directorio. A continuación, se presenta el análisis de su complejidad:

1. La función `parallel_highlight` realiza las siguientes operaciones:
   - Obtiene una lista de archivos en el directorio especificado utilizando `File.ls`, lo cual tiene una complejidad de tiempo O(n), donde n es el número de archivos que se encuentran dentro de este. 
   - Filtra la lista de archivos utilizando `Enum.filter`, que tiene una complejidad de tiempo O(m), donde m es el número de archivos que coinciden con el patrón de expresión regular (`~r/.py$/`), es decir, que es un archivo de Python.
   - Mapea cada archivo encontrado a una tarea asincrónica utilizando `Enum.map` y `Task.async`,dando una complejidad de tiempo O(m).
   - Espera a que todas las tareas se completen utilizando `Enum.map` y `Task.await`. Esto implica esperar a que m tareas finalicen, lo cual tiene una complejidad de tiempo O(m).

   Por lo tanto, la complejidad total de `parallel_highlight` es O(n + 2m) = O(n + m).

2. La función `highlight_syntax` realiza las siguientes operaciones:
   - Lee el contenido del archivo utilizando `File.read!`, lo cual tiene una complejidad de tiempo O(k), donde k es el tamaño del archivo en bytes.
   - Realiza la tokenización del contenido del archivo utilizando la función `tokenize`, que se analizará de manera contigua debido a su complejidad. 
   - Genera una representación HTML de los tokens utilizando `generate_html`, que también se analizará en un segundo plano. 
   - Escribe la salida HTML en un nuevo archivo utilizando `File.write`, lo cual tiene una complejidad de tiempo O(k).

   De esta manera, la complejidad de tiempo de `highlight_syntax` depende de las complejidades de `tokenize` y `generate_html`, que se analizan a continuación: 

3. La función `tokenize` recorre el contenido del archivo y realiza coincidencias de expresiones regulares en cada posición. Dado que hay 10 expresiones regulares en la lista `token_list`, la complejidad de tiempo de `tokenize` es O(k * 10), donde k es el tamaño del archivo en bytes.

4. La función `generate_html` itera sobre la lista de tokens y realiza operaciones de reemplazo y concatenación de cadenas para generar la representación HTML. La cantidad de iteraciones depende del número de tokens en la lista. Por lo tanto, la complejidad de tiempo de `generate_html` es O(p), donde p es el número de tokens.

En resumen, la complejidad de tiempo total del algoritmo se puede expresar como:

O(n + m + k + k * 10 + p) = O(n + m + 11k + p)

Donde:
- n es el número de archivos en el directorio
- m es el número de archivos que coinciden con el patrón de expresión regular
- k es el tamaño del archivo en bytes
- p es el número de tokens en el archivo


### Cálculo de __Speedup__

Se utiliza la fórmula siguiente: $S_p = T_1/T_p$, donde $p$ es el número de procesadores o núcleos, $T_1$ es el tiempo que tarda en ejecutarse la versión secuencial del programa, $T_p$ es el tiempo que tarda en ejecutarse la versión paralela del programa utilizando $p$ procesadores, y $S_p$ es el Speedup obtenido usando $p$ procesadores. 

En este caso, $T_1 = 9932 * 10^-3$ s, $T_p = 512 * 10^-3$, dando $S_p = 9932 * 10^-3/512 * 10^-3$
$S_p = 19.4$
De esta manera, se puede decir que un speedup de 19.4 significa que la nueva implementación en paralelo del programa es aproximadamente 19.4 veces más rápida que la versión secuencial. En otras palabras, el tiempo de ejecución se ha reducido significativamente, lo que indica un mejor rendimiento.

## Conclusiones

Al final del recorrido, el tipo de tecnología que desarrollamos, es decir, un resaltador de sintaxis en paralelo, mejora la implementación del anterior y además tiene consecuencias éticas importantes para la sociedad. Por un lado, permite que la comprensión de los códigos sea mucho más amigable con el usuario desarrollador, pero también puede hacer que la gente dependa demasiado de la tecnología y no logre comprender por sí misma lo que se está haciendo. De esta manera, se logra presentar los dos caras de la moneda,una en la que la tecnología ayuda a la humanidad pero a su vez la rinde completamente dependiente. 