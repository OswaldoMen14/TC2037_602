# Speedup

En computación paralela, el speedup se refiere a la mejora en el tiempo de ejecución de un programa cuando se usan múltiples procesadores o núcleos en comparación con el uso de un solo procesador. Mide la eficiencia ganada por la paralelización.

Se calcula con la siguiente fórmula:

$$ Sp = { T1 \over Tp } $$

Para la suma de los numeros primos entre **1 y 500,000**:

* **Speedup** = 2.08










